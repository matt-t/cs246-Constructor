#ifndef __EOFEXCEPTION_H__
#define __EOFEXCEPTION_H__

class EOFException {};

#endif
